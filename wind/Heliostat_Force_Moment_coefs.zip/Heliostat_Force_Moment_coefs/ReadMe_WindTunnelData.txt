For coordinate system, nomenclature, and more detailed discussion, see: 

www.google.org/pdfs/google_heliostat_wind_tunnel.pdf 

www.google.org/pdfs/google_heliostat_wind_tunnel_appendix.pdf

